import os
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image, ImageTk

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# --- Load icons once ---
def load_icon(filename):
    path = os.path.join("assets", filename)
    if os.path.exists(path):
        return ImageTk.PhotoImage(Image.open(path).resize((24, 24)))
    else:
        return None

icons = {
    "folder": load_icon("icon_folder.png"),
    "text": load_icon("icon_text.png"),
    "image": load_icon("icon_image.png"),
    "python": load_icon("icon_python.png"),
    "pdf": load_icon("icon_pdf.png"),
    "default": load_icon("icon_file.png")
}

# --- Main File Explorer Function ---
def file_explorer(start_path=os.getcwd()):
    window = ctk.CTkToplevel()
    window.geometry("800x500")
    window.title("BLACKDEE File Explorer")

    current_path = ctk.StringVar(value=start_path)

    # Top bar with path
    top_frame = ctk.CTkFrame(window)
    top_frame.pack(fill="x", pady=5, padx=5)

    path_entry = ctk.CTkEntry(top_frame, textvariable=current_path, width=600)
    path_entry.pack(side="left", padx=10, pady=10)

    def go_to_path():
        new_path = path_entry.get()
        if os.path.isdir(new_path):
            load_folder(new_path)
        else:
            messagebox.showerror("Invalid Path", "This folder does not exist.")

    go_btn = ctk.CTkButton(top_frame, text="Go", command=go_to_path)
    go_btn.pack(side="left", padx=5)

    # Scrollable file display
    file_frame = ctk.CTkScrollableFrame(window, orientation="vertical", width=780, height=420)
    file_frame.pack(padx=10, pady=10, fill="both", expand=True)

    def get_icon_for_file(filename):
        if os.path.isdir(filename):
            return icons["folder"]
        ext = os.path.splitext(filename)[1].lower()
        if ext == ".txt":
            return icons["text"]
        elif ext in [".png", ".jpg", ".jpeg"]:
            return icons["image"]
        elif ext == ".py":
            return icons["python"]
        elif ext == ".pdf":
            return icons["pdf"]
        else:
            return icons["default"]

    def load_folder(folder_path):
        for widget in file_frame.winfo_children():
            widget.destroy()
        current_path.set(folder_path)

        try:
            items = os.listdir(folder_path)
            items.sort()
            if os.path.dirname(folder_path) != folder_path:
                # Go back
                def go_back():
                    load_folder(os.path.dirname(folder_path))
                back_btn = ctk.CTkButton(file_frame, text=".. (Go Back)", command=go_back)
                back_btn.pack(anchor="w", pady=3, padx=10)

            for item in items:
                full_path = os.path.join(folder_path, item)
                icon = get_icon_for_file(full_path)

                def make_open_path(path=full_path):
                    def open_item():
                        if os.path.isdir(path):
                            load_folder(path)
                        else:
                            messagebox.showinfo("File", f"You selected file:\n{path}")
                    return open_item

                row = ctk.CTkFrame(file_frame)
                row.pack(fill="x", padx=10, pady=2)

                if icon:
                    img_label = ctk.CTkLabel(row, image=icon, text="")
                    img_label.pack(side="left", padx=5)

                file_btn = ctk.CTkButton(row, text=item, anchor="w", command=make_open_path())
                file_btn.pack(side="left", fill="x", expand=True)

        except Exception as e:
            messagebox.showerror("Error", str(e))

    load_folder(start_path)

# --- Root Window ---
root = ctk.CTk()
root.geometry("400x250")
root.title("BLACKDEE OS")

ctk.CTkLabel(root, text="BLACKDEE Desktop", font=("Segoe UI", 20)).pack(pady=30)
ctk.CTkButton(root, text="Open File Explorer", command=file_explorer).pack(pady=10)

root.mainloop()