import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, PhotoImage
from PIL import Image, ImageTk
import math
import pygame
import webbrowser
import time






# Theme colors
theme_colors = {
    "default": {"theme": "#2e3440", "taskbar": "#3b4252", "text": "#eceff4", "button": "#5e81ac", "hover": "#81a1c1"},
    "light": {"theme": "#ffffff", "taskbar": "#dcdcdc", "text": "#000000", "button": "#d3d3d3", "hover": "#c0c0c0"}
}
current_theme = "default"

# Initialize main window
root = tk.Tk()
root.title("BLACKDEE")
root.geometry("720x1544")
root.configure(bg=theme_colors[current_theme]["theme"])

# Bottom Taskbar (Main)
taskbar = tk.Frame(root, bg=theme_colors[current_theme]["taskbar"], height=50,padx=0.10)
taskbar.pack(side="bottom", fill="x")

# Right Taskbar (Only Open Apps)
right_taskbar = tk.Frame(root, bg=theme_colors[current_theme]["taskbar"], width=150)
right_taskbar.pack(side="right", fill="y")

# Installed Apps List
installed_apps = ["File Explorer", "Settings", "Calculator", "Notepad", "Image Viewer", "about"," Shutdown",  "terminal", "tik tok toe", "musicplayer", "google", "Paint", "clock", "todo list"]

start_menu_var = tk.StringVar()
start_menu_var.set("Start")

start_menu = ttk.OptionMenu(
    taskbar, start_menu_var, *["Start"] + installed_apps, command=lambda app: open_app(app)
)
start_menu.pack(side="bottom", padx=0)

os_label = ttk.Label(taskbar, text="BLACKDEE ", background=theme_colors[current_theme]["taskbar"], foreground="gray")
os_label.pack(padx=50, pady=0.00001)


def update_clock():
    """Update the clock every second."""
    current_time = time.strftime("%H:%M:%S")  # Get current time
    clock_label.config(text=current_time)  # Update label text
    clock_label.after(1000, update_clock)  # Call function again after 1 second

# Create the clock label in the taskbar
clock_label = tk.Label(taskbar, text="", bg=theme_colors[current_theme]["taskbar"], fg="blue", font=("Arial", 13))
clock_label.pack(side="left", padx=0.02, pady=0.01)

# Start updating the clock
update_clock()

# Store running apps
running_apps = {}

def update_taskbar():
    """Update the right-side taskbar with currently open apps."""
    for widget in right_taskbar.winfo_children():
        widget.destroy()

    for app_name in running_apps.keys():
        ttk.Button(
            right_taskbar,
            text=app_name,
            command=lambda a=app_name: running_apps[a].lift()
        ).pack(pady=5, padx=5, fill="x")

def app_window(app_name, size):
    """Create a new window for an app."""
    window = tk.Toplevel(root)
    window.title(app_name)
    window.geometry(size)
    window.configure(bg=theme_colors[current_theme]["theme"])
    running_apps[app_name] = window

    def close_app():
        """Close the app and update the taskbar."""
        del running_apps[app_name]
        window.destroy()
        update_taskbar()

    window.protocol("WM_DELETE_WINDOW", close_app)
    update_taskbar()
    return window
    
# Open apps
def open_app(app_name):
    if app_name in running_apps:
        running_apps[app_name].lift()
        return
    if app_name == "terminal":
        open_file_terminal() 
    if app_name == "File Explorer":
        open_file_explorer()
    elif app_name == "Settings":
        open_settings()
    elif app_name == "Calculator":
        open_calculator()
    elif app_name == "Notepad":
        open_notepad()
    elif app_name == "Image Viewer":
        open_file_imageviewer()
    elif app_name == "about":
        open_file_about()
    elif app_name == "tik tok toe":
       tic_tac_toe()
    elif app_name == "musicplayer":
       music_player() 
    elif app_name == "google":
       web_browser()
    elif app_name == "Paint":
        paint_app()
    elif app_name == "clock":
        clock_app()  
    elif app_name == "todo list":
        todo_list()
    elif app_name == "Shutdown":
        shutdown()
 
# Example App: Notepad
def open_notepad():
    """Open the Notepad app."""
    window = app_window("Notepad", "400x400")
    text_area = scrolledtext.ScrolledText(window, wrap="word", font=("Arial", 12))
    text_area.pack(fill="both", expand=True)

def open_calculator():
    """Open a simple calculator."""
    if "Calculator" in running_apps:  # Prevent multiple instances
        running_apps["Calculator"].lift()
        return

    window = app_window("Calculator", "780x400")

    entry = ttk.Entry(window, font=("Arial", 18), justify="right")
    entry.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=5, pady=5)

    def button_click(value):
        """Handles button clicks and updates the entry field."""
        entry.insert("end", value)

    def calculate():
        """Evaluates the mathematical expression in the entry field."""
        try:
            result = eval(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def clear():
        """Clears the entry field."""
        entry.delete(0, "end")

    def square():
        """Calculates the square of the number."""
        try:
            result = float(entry.get()) ** 2
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def square_root():
        """Calculates the square root."""
        try:
            result = math.sqrt(float(entry.get()))
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def reciprocal():
        """Calculates the reciprocal (1/x)."""
        try:
            result = 1 / float(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    # Layout buttons
    buttons = [
        ("7", "8", "9", "/"),
        ("4", "5", "6", "*"),
        ("1", "2", "3", "-"),
        ("0", ".", "=", "+"),
    ]

    for i, row in enumerate(buttons):
        for j, btn_text in enumerate(row):
            ttk.Button(window, text=btn_text, command=lambda b=btn_text: button_click(b) if b != "=" else calculate()).grid(
                row=i + 1, column=j, sticky="nsew", padx=5, pady=5
            )

    # Special operation buttons
    ttk.Button(window, text="C", command=clear).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="√", command=square_root).grid(row=5, column=2, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="x²", command=square).grid(row=5, column=3, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="1/x", command=reciprocal).grid(row=4, column=3, sticky="nsew", padx=5, pady=5)

    update_taskbar()  # Update the taskbar to show the running app
# Run the main loop

# 1. Terminal App
def open_file_terminal():
    def run_command():
        command = command_entry.get()
        if command.startswith("linux dpt install "):
            app_name = command.replace("linux dpt install ", "").strip()
            if app_name and app_name not in installed_apps:
                installed_apps.append(app_name)
                update_dock()
                terminal_output.insert("end", f"Installed {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is already installed.\n")
        else:
            try:
                output = subprocess.getoutput(command)
                terminal_output.insert("end", f"> {command}\n{output}\n")
            except Exception as e:
                terminal_output.insert("end", f"Error: {str(e)}\n")
        terminal_output.see("end")
        command_entry.delete(0, "end")

    window = app_window("Terminal", "720x500")
    terminal_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 12), bg="black", fg="green")
    terminal_output.pack(fill="both", expand=True)
    command_entry = ttk.Entry(window, font=("Courier", 14))
    command_entry.pack(fill="x", padx=5, pady=5)
    ttk.Button(window, text="Run", command=run_command).pack()

def open_termux():
    window = app_window("Termux", "400x400")
    termux_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 0.50), bg="black", fg="green")
    termux_output.pack(fill="both", expand=True)
    termux_output.insert("end", "Termux Shell: Welcome!\n")
    termux_output.insert("end", "Use commands like 'ls' or 'pwd'.")
update_taskbar()

# File Explorer
def open_file_explorer():
    """Open a file explorer."""
    window = app_window("File Explorer", "720x500")
    ttk.Button(window, text="Browse Files", command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    else:
        messagebox.showinfo("File Selected", filepath)

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img



def open_settings():
    """Open the settings app."""
    window = app_window("Settings", "400x400")

    ttk.Label(window, text="BLACKDEE - Settings", font=("Arial", 14)).pack(pady=10)

    # Theme and Wallpaper
    ttk.Button(window, text="Change Theme", command=change_theme).pack(pady=5)
    ttk.Button(window, text="Change Wallpaper", command=change_wallpaper).pack(pady=5)
    
    

    # Additional Settings
    ttk.Button(window, text="Adjust Screen Brightness", command=adjust_brightness).pack(pady=5)
    ttk.Button(window, text="Change Font Size", command=change_font_size).pack(pady=5)
    ttk.Button(window, text="Enable/Disable Sound", command=toggle_sound).pack(pady=5)
    ttk.Button(window, text="Set Default Apps", command=set_default_apps).pack(pady=5)
    ttk.Button(window, text="Manage Storage", command=manage_storage).pack(pady=5)
    ttk.Button(window, text="Change Language", command=change_language).pack(pady=5)
    ttk.Button(window, text="Update BLACKDEE", command=update_blackdee).pack(pady=5)
    ttk.Button(window, text="Check Battery Status", command=check_battery_status).pack(pady=5)
    ttk.Button(window, text="Reset to Factory Settings", command=reset_factory).pack(pady=5)
    ttk.Button(window, text="Privacy & Security", command=privacy_security).pack(pady=5)

def change_theme():
    """Switch between light and default themes."""
    global current_theme
    current_theme = "light" if current_theme == "default" else "default"
    root.configure(bg=theme_colors[current_theme]["theme"])
    taskbar.configure(bg=theme_colors[current_theme]["taskbar"])
    right_taskbar.configure(bg=theme_colors[current_theme]["taskbar"])
    os_label.configure(background=theme_colors[current_theme]["taskbar"])
    messagebox.showinfo("Theme Changed", f"Switched to {current_theme} theme.")

def change_wallpaper():
    file_path = filedialog.askopenfilename(title="Select Wallpaper", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
    if file_path:
        messagebox.showinfo("Wallpaper Changed", f"Wallpaper set to {file_path}")

def adjust_brightness():
    messagebox.showinfo("Brightness", "Brightness adjustment coming soon.")

def change_font_size():
    new_size = tk.simpledialog.askinteger("Font Size", "Enter new font size (e.g., 12, 14, 16):")
    if new_size:
        messagebox.showinfo("Font Size Changed", f"Font size set to {new_size}")

def toggle_sound():
    global sound_enabled
    sound_enabled = not sound_enabled
    state = "Enabled" if sound_enabled else "Disabled"
    messagebox.showinfo("Sound", f"Sound {state}")

def set_default_apps():
    apps = ["Browser", "Text Editor", "Music Player"]
    choice = tk.simpledialog.askstring("Default Apps", f"Enter default app ({', '.join(apps)}):")
    if choice in apps:
        messagebox.showinfo("Default App", f"Default {choice} set successfully.")

def manage_storage():
    total_space = "500GB"
    used_space = "200GB"
    free_space = "300GB"
    messagebox.showinfo("Storage Info", f"Total: {total_space}\nUsed: {used_space}\nFree: {free_space}")

def change_language():
    languages = ["English", "Spanish", "French"]
    choice = tk.simpledialog.askstring("Language", f"Choose language ({', '.join(languages)}):")
    if choice in languages:
        messagebox.showinfo("Language", f"Language set to {choice}")

def update_blackdee():
    webbrowser.open("https://blackdee-update.com")  # Replace with actual update URL
    messagebox.showinfo("Update", "Checking for updates...")

def check_battery_status():
    battery_status = "80% (Charging)"
    messagebox.showinfo("Battery Status", f"Battery: {battery_status}")

def reset_factory():
    confirm = messagebox.askyesno("Factory Reset", "Are you sure you want to reset BLACKDEE?")
    if confirm:
        messagebox.showinfo("Reset", "System resetting...")

def privacy_security():
    messagebox.showinfo("Privacy & Security", "Manage privacy settings in this section.")

# Global Variables
sound_enabled = True
        
#about
def open_file_about():
    """Open a new window to show the About app image."""
    about_window = tk.Toplevel(root)  # Create a new window
    about_window.title("About BLACKDEE")

    # Load the image safely
    try:
        img_path = r"D:\BLACKDEE WINDOWS\about app icons\about.png"  # Update with your correct path
        img = Image.open(img_path)
        img = img.resize((1300, 600))  # Resize if needed
        img_tk = ImageTk.PhotoImage(img.copy())  # Ensure it's not garbage collected

        # Create a label to display the image
        img_label = tk.Label(about_window, image=img_tk)
        img_label.image = img_tk  # Keep reference
        img_label.pack(padx=10, pady=10)

    except Exception as e:
        error_label = tk.Label(about_window, text=f"Error loading image:\n{e}", fg="red")
        error_label.pack(pady=10)


#image viewer
def open_file_imageviewer():
    """Open a file explorer."""
    window = app_window("Image viewer", "720x500")
    ttk.Button(window, text="Image viewer", command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    else:
        messagebox.showinfo("File Selected", filepath)

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img
    
# adding tik tok toe


def tic_tac_toe():
    
    ttt_window = app_window("tik tok toe", "500x400")

    # Initialize game state
    board = [""] * 10
    current_player = "X"

    def check_winner():
        winning_combinations = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
                                (0, 3, 6), (1, 4, 7), (2, 5, 8),
                                (0, 4, 8), (2, 4, 6)]
        for combo in winning_combinations:
            if board[combo[0]] == board[combo[1]] == board[combo[2]] and board[combo[0]] != "":
                return board[combo[0]]
        return None

    def make_move(index):
        nonlocal current_player
        if board[index] == "":
            board[index] = current_player
            buttons[index].config(text=current_player)

            winner = check_winner()
            if winner:
                result_label.config(text=f"Player {winner} wins!")
                for button in buttons:
                    button.config(state="disabled")
            elif "" not in board:
                result_label.config(text="It's a tie!")
            else:
                current_player = "O" if current_player == "X" else "X"

    # Create buttons for the Tic-Tac-Toe grid
    buttons = []
    for i in range(9):
        button = tk.Button(ttt_window, text="", font=("Arial", 8), width=5, height=2,
                           command=lambda index=i: make_move(index))
        button.grid(row=i // 3, column=i % 3)
        buttons.append(button)

    result_label = tk.Label(ttt_window, text="", font=("Arial", 14))
    result_label.grid(row=3, columnspan=3)

#adding music player
def music_player():
    window = app_window("Music Player", "400x200")
    
    def play_music():
        file_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3;*.wav")])
        if file_path:
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()

    def stop_music():
        pygame.mixer.music.stop()

    ttk.Button(window, text="Play Music", command=play_music).pack(pady=20)
    ttk.Button(window, text="Stop Music", command=stop_music).pack(pady=20)

# creating web brower

def web_browser():
    window = app_window("Web Browser", "400x400")

    def open_url():
        url = entry.get()
        webbrowser.open(url)

    entry = ttk.Entry(window, width=40)
    entry.pack(pady=20)
    ttk.Button(window, text="Open URL", command=open_url).pack(pady=10)
    
#adding paint

def paint_app():
    window = app_window("Paint", "600x400")
    
    # Create a canvas for drawing
    canvas = tk.Canvas(window, bg="white", width=600, height=400)
    canvas.pack(fill="both", expand=True)
    
    # Initialize variables
    current_tool = "pen"
    pen_color = "black"
    
    def paint(event):
        """Draws on the canvas based on the selected tool."""
        x1, y1 = (event.x - 2), (event.y - 2)
        x2, y2 = (event.x + 2), (event.y + 2)
        if current_tool == "pen":
            canvas.create_oval(x1, y1, x2, y2, fill=pen_color, outline=pen_color)
        elif current_tool == "eraser":
            canvas.create_rectangle(x1, y1, x2, y2, fill="white", outline="white")
    
    def set_tool(tool):
        """Sets the current drawing tool."""
        nonlocal current_tool
        current_tool = tool
    
    def set_color(new_color):
        """Changes the pen color."""
        nonlocal pen_color
        pen_color = new_color
    
    def draw_line():
        """Activates line drawing mode."""
        set_tool("line")
        canvas.bind("<Button-1>", start_line)
        canvas.bind("<ButtonRelease-1>", end_line)
    
    def start_line(event):
        """Stores start position for line drawing."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_line(event):
        """Draws a line from start to end position."""
        canvas.create_line(canvas.start_x, canvas.start_y, event.x, event.y, fill=pen_color, width=2)
    
    def draw_rectangle():
        """Activates rectangle drawing mode."""
        set_tool("rectangle")
        canvas.bind("<Button-1>", start_rectangle)
        canvas.bind("<ButtonRelease-1>", end_rectangle)
    
    def start_rectangle(event):
        """Stores start position for rectangle."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_rectangle(event):
        """Draws a rectangle from start to end position."""
        canvas.create_rectangle(canvas.start_x, canvas.start_y, event.x, event.y, outline=pen_color, width=2)
    
    def draw_circle():
        """Activates circle drawing mode."""
        set_tool("circle")
        canvas.bind("<Button-1>", start_circle)
        canvas.bind("<ButtonRelease-1>", end_circle)
    
    def start_circle(event):
        """Stores start position for circle."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_circle(event):
        """Draws a circle from start to end position."""
        x1, y1 = canvas.start_x, canvas.start_y
        x2, y2 = event.x, event.y
        canvas.create_oval(x1, y1, x2, y2, outline=pen_color, width=2)
    
    def clear_canvas():
        """Clears the canvas."""
        canvas.delete("all")
    
    def save_canvas():
        """Saves the canvas as an image."""
        file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                 filetypes=[("PNG files", "*.png"), ("All Files", "*.*")])
        if file_path:
            canvas.postscript(file="temp_canvas.ps", colormode="color")
            img = Image.open("temp_canvas.ps")
            img.save(file_path)
            messagebox.showinfo("Saved", "Image saved successfully!")

    # Color palette with 20 colors
    colors = ["black", "gray", "red", "blue", "green", "yellow", "orange", "purple", "pink", "brown",
              "cyan", "magenta", "lime", "navy", "gold", "maroon", "teal", "violet", "indigo", "darkgreen"]
    
    color_frame = tk.Frame(window)
    color_frame.pack()
    
    for color in colors:
        btn = tk.Button(color_frame, bg=color, width=1, command=lambda c=color: set_color(c))
        btn.pack(side="left", padx=0.008, pady=0.008)
    
    # Tools
    
    ttk.Button(window, text="Pen", command=lambda: set_tool("pen")).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Eraser", command=lambda: set_tool("eraser")).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Line", command=draw_line).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Rectangle", command=draw_rectangle).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Circle", command=draw_circle).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Clear", command=clear_canvas).pack(side="left", padx=5, pady=5)
    ttk.Button(window, text="Save", command=save_canvas).pack(side="left", padx=5, pady=5)
    
    canvas.bind("<B1-Motion>", paint)  # Allows continuous drawing

#adding clock     
def clock_app():
    window = app_window("Clock", "400x200")
    
    def update_clock():
        current_time = time.strftime("%H:%M:%S")
        clock_label.config(text=current_time)
        window.after(1000, update_clock)

    clock_label = ttk.Label(window, font=("Arial", 48))
    clock_label.pack(pady=20)
    update_clock()

                                        
# todo list
def todo_list():
    window = app_window("To-Do List", "400x400")
    
    tasks = []

    def add_task():
        task = entry.get()
        if task:
            tasks.append(task)
            listbox.insert("end", task)
            entry.delete(0, "end")

    def remove_task():
        selected_task = listbox.curselection()
        if selected_task:
            task_index = selected_task[0]
            listbox.delete(task_index)
            tasks.pop(task_index)

    entry = ttk.Entry(window, width=40)
    entry.pack(pady=10)
    ttk.Button(window, text="Add Task", command=add_task).pack(pady=5)
    ttk.Button(window, text="Remove Task", command=remove_task).pack(pady=5)

    listbox = tk.Listbox(window, height=10, width=50)
    listbox.pack(pady=10)                                                                                          
import tkinter as tk
from tkinter import messagebox
import sys

def shutdown():
    confirm = messagebox.askyesno("Shutdown", "Are you sure you want to shut down BLACKDEE?")
    if confirm:
        root.destroy()  # Closes the entire OS

shutdown_button = ttk.Button(taskbar, text="Shut Down", command=shutdown)
shutdown_button.pack(side="right", padx=0.0001, pady=0.000002)


root.mainloop()
