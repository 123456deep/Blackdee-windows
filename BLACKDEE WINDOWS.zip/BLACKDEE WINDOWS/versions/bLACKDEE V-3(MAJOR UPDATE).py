#--------------------------------------------------------------------------------------------------#
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext, PhotoImage
from PIL import Image, ImageTk
import math
import pygame
import webbrowser
import time
import cv2
import os
import ffmpeg
import customtkinter as ctk
from tkinter import Canvas
import threading
from datetime import datetime
from tkhtmlview import HTMLLabel
import webview
from ctypes import windll, byref, sizeof, c_int
from ctypes.wintypes import HWND, DWORD
import numpy as np
import pygetwindow as gw
import pyautogui
import win32gui
import win32con
import win32api
import win32ui
import random
import subprocess
import psutil
#----------------------------------------------------------------------------------------------------#



# Initialize CustomTkinter
ctk.set_appearance_mode("dark")  
ctk.set_default_color_theme("blue")




# Correct Password
CORRECT_PASSWORD = "blackdee"
CORRECT_USERNAME = "root"
def open_login_screen():
    global login_window, password_entry, login_button, error_label, time_label,username_entry
    login_window = ctk.CTk()
    login_window.title("BLACKDEE Login")
    login_window.geometry(f"{login_window.winfo_screenwidth()}x{login_window.winfo_screenheight()}+0+0")
    login_window.configure(bg="black")
    login_window.attributes("-fullscreen", True)
    # ---------- Time and Date Update ----------
    def update_time():
        # Use after instead of an infinite loop
        current_time = datetime.now().strftime("%H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d")
        time_label.configure(text=f"{current_date} | {current_time}")
        login_window.after(1000, update_time)
    # ---------- Loading Animation (Arc and Animated Text) ----------
    def show_loading():
        # Hide login widgets
        password_entry.pack_forget()
        login_button.pack_forget()
        error_label.pack_forget()
        time_label.pack_forget()
        username_entry.pack_forget()
        # Create a canvas for the circle loading animation (using tk.Canvas)
        canvas = tk.Canvas(login_window, width=200, height=200, bg="black", highlightthickness=0)
        canvas.pack(pady=50)
        # Create an arc (circle outline) starting at 90° with extent 0
        arc = canvas.create_arc(10, 10, 190, 190, start=90, extent=0, outline="white", width=5, style="arc")

        # Label for animated text below the canvas
        animated_label = ctk.CTkLabel(login_window, text="", font=("Arial", 20), text_color="white", bg_color="black")
        animated_label.pack(pady=20)

        steps = 100          # 100 steps for the 5-second animation
        delay = 50           # 50 ms per step --> total = 5000 ms (5 seconds)

        def update_arc(step):
            if step <= steps:
                # Update the arc extent (0 to 360 degrees)
                extent = (step / steps) * 360
                canvas.itemconfig(arc, extent=extent)
                login_window.after(delay, update_arc, step + 1)
            else:
                # After finishing the animation, wait briefly then open the main menu
                login_window.after(500, lambda: (login_window.destroy()))

        def animate_text(index=0):
            message = "logging to the user..."
            if index <= len(message):
                animated_label.configure(text=message+(CORRECT_USERNAME)[:index])
                # Update text every 100 ms for a typing effect
                login_window.after(100, animate_text, index + 1)

        update_arc(0)
        animate_text(0)

    # ---------- Login Check Function ----------
    
    def check_login():
        username = username_entry.get()
        password = password_entry.get()
        if username == CORRECT_USERNAME and password == CORRECT_PASSWORD:
            show_loading()  # Proceed with login
        elif username != CORRECT_USERNAME and password != CORRECT_PASSWORD:
            error_label.configure(text="Incorrect Password", text_color="red")
        elif password != CORRECT_PASSWORD:
            error_label.configure(text="Incorrect Password", text_color="red")
        elif username != CORRECT_USERNAME:
            error_label.configure(text="Incorrect Password", text_color="red")



                
    def exit_app(event):
        login_window.destroy()
    login_window.bind("<Escape>", exit_app)

    
    # ---------- Create Widgets for Login ----------
    time_label = ctk.CTkLabel(login_window, text="", font=("Arial", 20), text_color="white", bg_color="black")
    time_label.pack(pady=20)
    update_time()  # Start the time/date updates
    username_entry = ctk.CTkEntry(login_window, placeholder_text="Enter Username", font=("Arial", 24), width=300)
    username_entry.pack(pady=20)
    password_entry = ctk.CTkEntry(login_window, placeholder_text="Enter Password", show="*", font=("Arial", 24), width=300)
    password_entry.pack(pady=20)
    login_button = ctk.CTkButton(login_window, text="Login", command=check_login)
    login_button.pack(pady=10)
    error_label = ctk.CTkLabel(login_window, text="", font=("Arial", 18), text_color="white", bg_color="black")
    error_label.pack()
    login_window.mainloop()

# Theme colors
theme_colors = {
    "dark": {"theme": "#2e3440", "taskbar": "#3b4252", "text": "#eceff4",
        "button": "#5e81ac", "hover": "#81a1c1"
    },
    "light": {
        "theme": "#ffffff", "taskbar": "#dedede", "text": "#000000",
        "button": "#d3d3d3", "hover": "#c0c0c0"
    },
    "red": {
        "theme": "#3a0c02", "taskbar": "#7a1f0d", "text": "#ffffff",
        "button": "#d62828", "hover": "#ff6b6b"
    },
    "green": {
        "theme": "#0f3d0f", "taskbar": "#1e5625", "text": "#d4ffd4",
        "button": "#2ecc71", "hover": "#55efc4"
    },
    "blue": {
        "theme": "#001f3f", "taskbar": "#003366", "text": "#cce7ff",
        "button": "#0074cc", "hover": "#66a3ff"
    },
    "purple": {
        "theme": "#2c003e", "taskbar": "#4b0082", "text": "#f3e5f5",
        "button": "#9b59b6", "hover": "#c39bd3"
    },
    "orange": {
        "theme": "#7f4000", "taskbar": "#cc5500", "text": "#fff5e6",
        "button": "#ff7f00", "hover": "#ffaf40"
    },
    "pink": {
        "theme": "#ffccff", "taskbar": "#ff99cc", "text": "#660033",
        "button": "#ff66b2", "hover": "#ff3385"
    },
    "yellow": {
        "theme": "#ffffcc", "taskbar": "#ffeb99", "text": "#333300",
        "button": "#ffcc00", "hover": "#ffdd55"
    },
    "gray": {
        "theme": "#333333", "taskbar": "#444444", "text": "#ffffff",
        "button": "#666666", "hover": "#888888"
    }
}

current_theme = "dark"  # Change this to test different themes


open_login_screen()

# Replace with your video path


# Function to play video in background
root = tk.Tk()
root.title("BLACKDEE VERSION:-3(MAJOR UPDATE)") 
root.configure(bg=theme_colors[current_theme]["theme"])
root.attributes("-fullscreen", True)

# Initialize main window




#Enable blur effect (Windows only)
def blur_apply(hwnd):
    accent_policy = DWORD(2)  # ACCENT_ENABLE_BLURBEHIND
    windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, byref(accent_policy), sizeof(accent_policy))


#Create a floating taskbar

bar_width = 400  # Adjust width as needed bar_height = 50  # Adjust height as needed
bar_height = 500
#Calculate center position

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_pos = (screen_width - bar_width) // 2
y_pos = screen_height - 100  # Adjust distance from bottom

# Right Taskbar (Only Open Apps)
helper_taskbar = ctk.CTkFrame(root,height=bar_height,width=bar_width,corner_radius=50 , fg_color="#222")
helper_taskbar.place(x=x_pos,y=y_pos)


# Function to update battery percentage

# Bottom Taskbar (Main)





taskbar = ctk.CTkFrame(root, height=0.010,corner_radius=1000, fg_color="#222")
taskbar.pack(side="top", fill="x")

# Position the taskbar
blur_apply(taskbar.winfo_id())






# Right Taskbar (Only Open Apps)
right_taskbar = ctk.CTkFrame(root, corner_radius=1000 , fg_color="#222")
right_taskbar.pack(side="right", fill="y",padx=0.0001,pady=0.10)

# Installed Apps List
installed_apps = ["File Explorer","terminal","Settings","Calculator","Notepad","Image Viewer","about","tik tok toe",
"musicplayer","google","Paint","clock","todo list","Shutdown","Video Player","Text Viewer","LOG OUT","WindowsAppInstaller"]

#The start button
start_img=ctk.CTkImage(light_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\start_button.png"), 
                            dark_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\start_button.png"), 
                            size=(100, 55))  # Resize image
# Function to toggle the dropdown option menu
def open_start_menu():
    hide_menu()
    refresh_button.place_forget()

    global start_menu  # Ensure menu state is managed globally

    if "start_menu" in globals() and start_menu.winfo_exists():
        if start_menu.winfo_ismapped():
            start_menu.place_forget()  # Hide if already open
        else:
            start_menu.place(x=1, y=root.winfo_height() - 745)  # Show below Start button
    else:
        # Create the dropdown option menu
        start_menu_var = ctk.StringVar(value="Start")
        hide_menu()
        refresh_button.place_forget()  # Hide refresh button

        start_menu = ctk.CTkComboBox(
            root,
            variable=start_menu_var,
            values=["Start"] + installed_apps,
            command=open_app,
            width=200,
            height=40,
            corner_radius=40,
            fg_color="black",
            dropdown_fg_color="black",
            text_color="blue",
            dropdown_text_color="green"
        )
        start_menu.place(x=1, y=root.winfo_height() - 745)  # Adjust position
        

start_button = ctk.CTkButton(taskbar, text="", image=start_img, compound="left",
                                fg_color="black", hover_color="blue", 
                                text_color="red", corner_radius=100, 
                                command=open_start_menu)
start_button.pack(side="bottom",pady=0.000005)

# Function to refresh (hides both the button and menu)
def refresh_action():
    print("Refreshing...")  # Replace with actual refresh logic
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button
# File Explorer
import os
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image, ImageTk

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# --- Load icons once ---
def load_icon(filename):
    path = os.path.join("assets", filename)
    if os.path.exists(path):
        return ImageTk.PhotoImage(Image.open(path).resize((24, 24)))
    else:
        return None

icons = {
    "folder": load_icon("icon_folder.png"),
    "text": load_icon("icon_text.png"),
    "image": load_icon("icon_image.png"),
    "python": load_icon("icon_python.png"),
    "pdf": load_icon("icon_pdf.png"),
    "default": load_icon("icon_file.png")
}

# --- Main File Explorer Function ---
def open_file_explorer(start_path=os.getcwd()):
    window = app_window("FILE EXPLORER","750x500")
    
    window.title("BLACKDEE File Explorer")

    current_path = ctk.StringVar(value=start_path)

    # Top bar with path
    top_frame = ctk.CTkFrame(window)
    top_frame.pack(fill="x", pady=5, padx=5)

    path_entry = ctk.CTkEntry(top_frame, textvariable=current_path, width=600)
    path_entry.pack(side="left", padx=10, pady=10)

    def go_to_path():
        new_path = path_entry.get()
        if os.path.isdir(new_path):
            load_folder(new_path)
        else:
            messagebox.showerror("Invalid Path", "This folder does not exist.")

    go_btn = ctk.CTkButton(top_frame, text="Go", command=go_to_path)
    go_btn.pack(side="left", padx=5)

    # Scrollable file display
    file_frame = ctk.CTkScrollableFrame(window, orientation="vertical", width=780, height=420)
    file_frame.pack(padx=10, pady=10, fill="both", expand=True)

    def get_icon_for_file(filename):
        if os.path.isdir(filename):
            return icons["folder"]
        ext = os.path.splitext(filename)[1].lower()
        if ext == ".txt":
            return icons["text"]
        elif ext in [".png", ".jpg", ".jpeg"]:
            return icons["image"]
        elif ext == ".py":
            return icons["python"]
        elif ext == ".pdf":
            return icons["pdf"]
        else:
            return icons["default"]

    def load_folder(folder_path):
        for widget in file_frame.winfo_children():
            widget.destroy()
        current_path.set(folder_path)

        try:
            items = os.listdir(folder_path)
            items.sort()
            if os.path.dirname(folder_path) != folder_path:
                # Go back
                def go_back():
                    load_folder(os.path.dirname(folder_path))
                back_btn = ctk.CTkButton(file_frame, text=".. (Go Back)", command=go_back)
                back_btn.pack(anchor="w", pady=3, padx=10)

            for item in items:
                full_path = os.path.join(folder_path, item)
                icon = get_icon_for_file(full_path)

                def make_open_path(path=full_path):
                    def open_item():
                        if os.path.isdir(path):
                            load_folder(path)
                        else:
                            messagebox.showinfo("File", f"You selected file:\n{path}")
                    return open_item

                row = ctk.CTkFrame(file_frame)
                row.pack(fill="x", padx=10, pady=2)

                if icon:
                    img_label = ctk.CTkLabel(row, image=icon, text="")
                    img_label.pack(side="left", padx=5)

                file_btn = ctk.CTkButton(row, text=item, anchor="w", command=make_open_path())
                file_btn.pack(side="left", fill="x", expand=True)

        except Exception as e:
            messagebox.showerror("Error", str(e))

    load_folder(start_path)


def shutdown_terminal():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    confirm = messagebox.askyesno("Shutdown", "Are you sure you want to shut down BLACKDEE?")
    if confirm:
        root.destroy()  # Closes the entire OS

def open_file_terminal():
    hide_menu()
    refresh_button.place_forget()

    def run_command():
        command = command_entry.get().strip()
        parts = command.split()
        
        if not command:
            return

        if command == "clear":
            terminal_output.delete("1.0", "end")

        elif command.startswith("linux dpt install "):
            app_name = command.replace("linux dpt install ", "").strip()
            if app_name and app_name not in installed_apps:
                installed_apps.append(app_name)
                update_dock()
                terminal_output.insert("end", f"Installed {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is already installed.\n")



        elif command == "Blackdee dpt list":
           terminal_output.insert("end", "Installed apps:\n" + "\n".join(installed_apps) + "\n" if installed_apps else "No apps installed.\n")

        elif command == "SHUTDOWN":
            shutdown_terminal()


        elif command == "credits":
            terminal_output.insert("end", "---------------------------------------------------------------------"+"\n"+"DEVEOPED BY:-DEEPDHANRAY"+"\n"+"UPDATED BY:-DEEPDHANRAY"+"\n"+"---------------------------------------------------------------------"+"\n")




        elif command.startswith("Blackdee dpt remove "):
            app_name = command.replace("linux dpt remove ", "").strip()
            if app_name in installed_apps:
                installed_apps.remove(app_name)
                update_dock()
                terminal_output.insert("end", f"Uninstalled {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is not installed.\n")

        elif command.startswith("echo "):
            terminal_output.insert("end", command.replace("echo ", "") + "\n")

        elif command == "exit":
            window.destroy()

        elif command == "date":
            terminal_output.insert("end", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")

        elif command == "time":
            terminal_output.insert("end", datetime.datetime.now().strftime("%H:%M:%S") + "\n")

        elif command == "whoami":
            terminal_output.insert("end", os.getlogin() + "\n")

        elif command == "pwd":
            terminal_output.insert("end", os.getcwd() + "\n")

        elif command == "ls":
            terminal_output.insert("end", "\n".join(os.listdir()) + "\n")

        elif command.startswith("cd "):
            path = command.replace("cd ", "").strip()
            try:
                os.chdir(path)
                terminal_output.insert("end", f"Changed directory to {os.getcwd()}\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"Directory {path} not found.\n")

        elif command.startswith("mkdir "):
            dirname = command.replace("mkdir ", "").strip()
            os.makedirs(dirname, exist_ok=True)
            terminal_output.insert("end", f"Directory {dirname} created.\n")

        elif command.startswith("rmdir "):
            dirname = command.replace("rmdir ", "").strip()
            try:
                os.rmdir(dirname)
                terminal_output.insert("end", f"Directory {dirname} removed.\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"Directory {dirname} not found.\n")
            except OSError:
                terminal_output.insert("end", f"Directory {dirname} is not empty.\n")

        elif command.startswith("touch "):
            filename = command.replace("touch ", "").strip()
            open(filename, 'a').close()
            terminal_output.insert("end", f"File {filename} created.\n")

        elif command.startswith("rm "):
            filename = command.replace("rm ", "").strip()
            try:
                os.remove(filename)
                terminal_output.insert("end", f"File {filename} removed.\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"File {filename} not found.\n")

        elif command.startswith("cat "):
            filename = command.replace("cat ", "").strip()
            try:
                with open(filename, "r") as f:
                    terminal_output.insert("end", f.read() + "\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"File {filename} not found.\n")

        elif command.startswith("cp "):
            try:
                _, src, dest = parts
                os.system(f"cp {src} {dest}")
                terminal_output.insert("end", f"Copied {src} to {dest}.\n")
            except:
                terminal_output.insert("end", "Usage: cp <source> <destination>\n")

        elif command.startswith("mv "):
            try:
                _, src, dest = parts
                os.system(f"mv {src} {dest}")
                terminal_output.insert("end", f"Moved {src} to {dest}.\n")
            except:
                terminal_output.insert("end", "Usage: mv <source> <destination>\n")

        elif command == "df":
            terminal_output.insert("end", subprocess.getoutput("df -h") + "\n")

        elif command == "du":
            terminal_output.insert("end", subprocess.getoutput("du -sh *") + "\n")

        elif command == "ps":
            terminal_output.insert("end", subprocess.getoutput("ps") + "\n")

        elif command.startswith("kill "):
            pid = command.replace("kill ", "").strip()
            os.system(f"kill {pid}")
            terminal_output.insert("end", f"Process {pid} terminated.\n")

        elif command == "uptime":
            terminal_output.insert("end", subprocess.getoutput("uptime") + "\n")

        elif command == "random":
            terminal_output.insert("end", f"{random.randint(1, 100)}\n")

        elif command == "login":
            terminal_output.insert("end", "USERNAME:-root" + "\n" + "PASSWORD:-blackdee"+"\n")
        elif command == "help":
            terminal_output.insert("end", "clear:- clear all the commands"+"\n"+"SHUTDOWN:-SHUTDOWN the Blackdee"+"\n"+"credits:-Show the name of the developer and updater"+"\n"+"exit:-Close the terminal"+"\n"+"date:-Display the Today date"+"\n"+"Time:-SHOW the real time"+"\n"+"whoami:-SHOW that you are ADMIN or not"+"\n"+"ls:-Show all the available version"+"\n"+"cd:-Change the directory of the ls command"+"\n"+"mkdir:-create new directory"+"\n"+"rmdir:- sHow that the directory is empty or not"+"\n"+"kill:-used to close any blackdee running proccess"+"\n"+"login:-Show the username and password"+"\n"+"random:-Can pick any random number"+"\n")
        elif command == "color 1":
            fg="red"

        else:
            terminal_output.insert("end", f"{command}" " is not recognized as an internal or external command,"+"\n"+ "operable program or batch file." +"\n")

        terminal_output.see("end")
        command_entry.delete(0, "end")

    window = app_window("Terminal", "720x500")
    terminal_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 12), bg="black", fg="green")
    terminal_output.pack(fill="both", expand=True)

    command_entry = ctk.CTkEntry(window, font=("Courier", 14))
    command_entry.pack(fill="x", padx=5, pady=5)
    ctk.CTkButton(window, text="Run",fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=run_command).pack()

def open_settings():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open the settings app."""
    window = app_window("Settings", "400x400")
    hide_menu()
    refresh_button.place_forget()
    ttk.Label(window, text="BLACKDEE - Settings", font=("Arial", 14)).pack(pady=10)

    # Theme and Wallpaper
    ctk.CTkButton(window, text="Change Theme", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=change_theme).pack(pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Change Wallpaper", command=change_wallpaper).pack(pady=5)
    
    

    # Additional Settings
    ctk.CTkButton(window, text="Adjust Screen Brightness",  fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=adjust_brightness).pack(pady=5)
    ctk.CTkButton(window, text="Change Font Size", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=change_font_size).pack(pady=5)
    ctk.CTkButton(window, text="Enable/Disable Sound", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=toggle_sound).pack(pady=5)
    ctk.CTkButton(window, text="Set Default Apps",fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=set_default_apps).pack(pady=5)
    ctk.CTkButton(window, text="Manage Storage", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=manage_storage).pack(pady=5)
    ctk.CTkButton(window, text="Change Language", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=change_language).pack(pady=5)
    ctk.CTkButton(window, text="Update BLACKDEE", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=update_blackdee).pack(pady=5)
    ctk.CTkButton(window, text="Check Battery Status", command=check_battery_status).pack(pady=5)
    ctk.CTkButton(window, text="Reset to Factory Settings", command=reset_factory).pack(pady=5)
    ctk.CTkButton(window, text="Privacy & Security", command=privacy_security).pack(pady=5)


def change_theme():
    messagebox.showinfo("Theme", "Theme changing coming soon.")
    
def change_wallpaper():
    file_path = filedialog.askopenfilename(title="Select Wallpaper", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
    if file_path:
        messagebox.showinfo("Wallpaper Changed", f"Wallpaper set to {file_path}")

def adjust_brightness():
    messagebox.showinfo("Brightness", "Brightness adjustment coming soon.")

def change_font_size():
    new_size = tk.simpledialog.askinteger("Font Size", "Enter new font size (e.g., 12, 14, 16):")
    if new_size:
        messagebox.showinfo("Font Size Changed", f"Font size set to {new_size}")

def toggle_sound():
    global sound_enabled
    sound_enabled = not sound_enabled
    state = "Enabled" if sound_enabled else "Disabled"
    messagebox.showinfo("Sound", f"Sound {state}")

def set_default_apps():
    apps = ["Browser", "Text Editor", "Music Player"]
    choice = tk.simpledialog.askstring("Default Apps", f"Enter default app ({', '.join(apps)}):")
    if choice in apps:
        messagebox.showinfo("Default App", f"Default {choice} set successfully.")

def manage_storage():
    total_space = "500GB"
    used_space = "200GB"
    free_space = "300GB"
    messagebox.showinfo("Storage Info", f"Total: {total_space}\nUsed: {used_space}\nFree: {free_space}")

def change_language():
    languages = ["English", "Spanish", "French"]
    choice = tk.simpledialog.askstring("Language", f"Choose language ({', '.join(languages)}):")
    if choice in languages:
        messagebox.showinfo("Language", f"Language set to {choice}")

def update_blackdee():
    webbrowser.open("https://blackdee-update.com")  # Replace with actual update URL
    messagebox.showinfo("Update", "Checking for updates...")

    
def check_battery_status():
    messagebox.showinfo("Coming soon!")

def reset_factory():
    confirm = messagebox.askyesno("Factory Reset", "Are you sure you want to reset BLACKDEE?")
    if confirm:
        messagebox.showinfo("Reset", "System resetting...")

def privacy_security():
    messagebox.showinfo("Privacy & Security", "Manage privacy settings in this section.")

# Global Variables
sound_enabled = True

def open_calculator():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a simple calculator."""
    if "Calculator" in running_apps:  # Prevent multiple instances
        running_apps["Calculator"].lift()
        return

    window = app_window("Calculator", "780x400")

    entry = ctk.CTkEntry(window, font=("Arial", 18), justify="right")
    entry.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=5, pady=5)

    def button_click(value):
        """Handles button clicks and updates the entry field."""
        entry.insert("end", value)

    def calculate():
        """Evaluates the mathematical expression in the entry field."""
        try:
            result = eval(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def clear():
        """Clears the entry field."""
        entry.delete(0, "end")

    def square():
        """Calculates the square of the number."""
        try:
            result = float(entry.get()) ** 2
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def square_root():
        """Calculates the square root."""
        try:
            result = math.sqrt(float(entry.get()))
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def reciprocal():
        """Calculates the reciprocal (1/x)."""
        try:
            result = 1 / float(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    # Layout buttons
    buttons = [
        ("7", "8", "9", "/"),
        ("4", "5", "6", "*"),
        ("1", "2", "3", "-"),
        ("0", ".", "=", "+"),
    ]

    for i, row in enumerate(buttons):
        for j, btn_text in enumerate(row):
            ctk.CTkButton(window, corner_radius=100,text=btn_text, command=lambda b=btn_text: button_click(b) if b != "=" else calculate()).grid(
                row=i + 1, column=j, sticky="nsew", padx=5, pady=5
            )

    # Special operation buttons
    ctk.CTkButton(window, text="C", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=clear).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="√", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=square_root).grid(row=5, column=2, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="x²", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=square).grid(row=5, column=3, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="1/x", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=reciprocal).grid(row=4, column=3, sticky="nsew", padx=5, pady=5)

    update_taskbar()  # Update the taskbar to show the running app
# Run the main loop

def clock_menu_app():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    window = app_window("Clock", "400x200")
    def update_clock():
        """Update the clock every second (both digital and analog)."""
        current_time = time.strftime("%I:%M:%S")  # Get current time
        clock_label.config(text=current_time)  # Update digital clock text
        # Clear previous clock drawing
        clock_canvas.delete("all")
        # Draw clock face
        clock_canvas.create_oval(10, 10, 110, 110, outline="black", width=3, fill="yellow")
        # Draw numbers
        for i in range(1, 13):
            angle = math.radians(i * 30 - 90)
            x = 60 + 40 * math.cos(angle)
            y = 60 + 40 * math.sin(angle)
            clock_canvas.create_text(x, y, text=str(i), font=("Arial", 10, "bold"), fill="black")
        # Get current time values
        hours = int(time.strftime("%I"))
        minutes = int(time.strftime("%M"))
        seconds = int(time.strftime("%S"))
        # Calculate angles
        second_angle = math.radians((seconds * 6) - 90)
        minute_angle = math.radians((minutes * 6) - 90)
        hour_angle = math.radians((hours * 30 + minutes * 0.5) - 90)
        # Draw hands
        def draw_hand(angle, length, color, width=2):
            x = 60 + length * math.cos(angle)
            y = 60 + length * math.sin(angle)
            clock_canvas.create_line(60, 60, x, y, fill=color, width=width)
        draw_hand(hour_angle, 25, "black", 4)
        draw_hand(minute_angle, 35, "blue", 3)
        draw_hand(second_angle, 40, "red", 1)
        # Schedule next update
        clock_label.after(1000, update_clock)
        #creating a animation time# Create taskbar clock UI elements
    clock_label = tk.Label(window, text="", fg="blue", font=("Arial", 1, "bold"))
    clock_canvas = Canvas(window,width=120, height=120, bg="#2e3440")
    clock_canvas.pack(side="left", padx=5, pady=5)
    update_clock()
    clock_label = tk.Label(window, text="", bg=theme_colors[current_theme]["taskbar"], fg="blue", font=("Arial", 30))
    clock_label.pack(side="left", padx=0.02, pady=0.01)
# Start updating the clock
    update_clock()

# Function to hide menu
def hide_menu(*args):
    option_menu.place_forget()
    refresh_button.place_forget()

# Function to show menu and refresh button at cursor position
def show_menu(event):
    option_menu.place(x=event.x, y=event.y)

# Dictionary to map menu options to functions
menu_actions = {
    "Refresh":
    refresh_action,
    "Clock":
    clock_menu_app,
    "Browse File":
    open_file_explorer,
    "Terminal":
    open_file_terminal,
    "Settings":
    open_settings,
    "Calculator":
    open_calculator
}

# Function to handle menu selection
def menu_action(selection):
    menu_actions.get(selection, lambda: None)()  # Call function if exists, else do nothing

# Create a refresh button (hidden initially)
refresh_button = ctk.CTkButton(root, text="Refresh", command=refresh_action)
refresh_button.place_forget()

# Create a list of menu options (excluding Refresh since it's now a button)
menu_options = ["Refresh","Refresh","Terminal", "Settings", "Browse File","Calculator","Clock"]

# Create a Tkinter variable to hold the selected option
selected_option = tk.StringVar(value="Menu")

# Create an OptionMenu (dropdown menu)
option_menu = ttk.OptionMenu(root, selected_option, *menu_options, command=menu_action)
option_menu.place_forget()  # Hide by default

# Bind right-click (Button-3) and double-click (Double-Button-1) to show menu
root.bind("<Button-3>", show_menu)  # Right-click

def exit_app(event):
    root.destroy()
root.bind("<Escape>", exit_app)

def update_clock():
    """Update the clock every second (both digital and analog)."""
    current_time = time.strftime("%I:%M:%S")  # Get current time
    clock_label.config(text=current_time)  # Update digital clock text

    # Clear previous clock drawing
    clock_canvas.delete("all")

    # Draw clock face
    clock_canvas.create_oval(10, 10, 110, 110, outline="black", width=3, fill="yellow")

    # Draw numbers
    for i in range(1, 13):
        angle = math.radians(i * 30 - 90)
        x = 60 + 40 * math.cos(angle)
        y = 60 + 40 * math.sin(angle)
        clock_canvas.create_text(x, y, text=str(i), font=("Arial", 10, "bold"), fill="black")

    # Get current time values
    hours = int(time.strftime("%I"))
    minutes = int(time.strftime("%M"))
    seconds = int(time.strftime("%S"))

    # Calculate angles
    second_angle = math.radians((seconds * 6) - 90)
    minute_angle = math.radians((minutes * 6) - 90)
    hour_angle = math.radians((hours * 30 + minutes * 0.5) - 90)

    # Draw hands
    def draw_hand(angle, length, color, width=2):
        x = 60 + length * math.cos(angle)
        y = 60 + length * math.sin(angle)
        clock_canvas.create_line(60, 60, x, y, fill=color, width=width)

    draw_hand(hour_angle, 25, "black", 4)
    draw_hand(minute_angle, 35, "blue", 3)
    draw_hand(second_angle, 40, "red", 1)

    # Schedule next update
    clock_label.after(1000, update_clock)

# Create taskbar clock UI elements
clock_label = tk.Label(helper_taskbar, text="", fg="blue", font=("Arial", 1, "bold"))
clock_canvas = Canvas(root,width=120, height=120, bg="#2e3440")
clock_canvas.pack(side="left", padx=5, pady=5)

update_clock()  # Start the clock


# Create the clock label in the taskbar
clock_label = tk.Label(helper_taskbar, text="", bg=theme_colors[current_theme]["taskbar"], fg="blue", font=("Arial", 13))
clock_label.pack(side="left", padx=0.02, pady=10)

# Start updating the clock
update_clock()

# Store running apps
running_apps = {}

def update_taskbar():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Update the right-side taskbar with currently open apps."""
    for widget in right_taskbar.winfo_children():
        widget.destroy()

    for app_name in running_apps.keys():
        ttk.Button(
            right_taskbar,
            text=app_name,
            command=lambda a=app_name: running_apps[a].lift()
        ).pack(pady=5, padx=5, fill="x")

def app_window(app_name, size):
    """Create a new window for an app."""
    window = ctk.CTkToplevel(root)
    window.title(app_name)
    window.geometry(size)
    window.configure(bg=theme_colors[current_theme]["theme"])
    running_apps[app_name] = window

    def close_app():
        """Close the app and update the taskbar."""
        del running_apps[app_name]
        window.destroy()
        update_taskbar()

    window.protocol("WM_DELETE_WINDOW", close_app)
    update_taskbar()
    return window
    
# Open apps
def open_app(app_name):
    if app_name in running_apps:
        running_apps[app_name].lift()
        return
    if app_name == "terminal":
        open_file_terminal() 
    if app_name == "File Explorer":
        open_file_explorer()
    elif app_name == "Settings":
        open_settings()
    elif app_name == "Calculator":
        open_calculator()
    elif app_name == "Notepad":
        open_notepad()
    elif app_name == "Image Viewer":
        open_file_imageviewer()
    elif app_name == "about":
        open_file_about()
    elif app_name == "tik tok toe":
       tic_tac_toe()
    elif app_name == "musicplayer":
       music_player() 
    elif app_name == "google":
       CustomWebBrowser()
    elif app_name == "Paint":
        paint_app()
    elif app_name == "clock":
        clock_app()  
    elif app_name == "todo list":
        todo_list()
    elif app_name == "Shutdown":
        shutdown()
    elif app_name == "Video Player":
        open_video_player()
    elif app_name == "Text Viewer":
        open_file_txt()
    elif app_name == "LOG OUT":
        open2_login_screen()
    elif app_name == "WindowsAppInstaller":
        WindowsAppInstaller()
CORRECT_PASSWORD = "blackdee"
CORRECT_USERNAME = "root"


INSTALL_DIR = r'D:/BLACKDEE WINDOWS/INSTALLED APPS'

def WindowsAppInstaller():
    def init(self, root):
        self.root = root
        self.root.title("Windows App Installer")
        # Make it appear in taskbar
        self.root.iconify()
        self.root.deiconify()
        # Auto-adjust window size
        self.root.geometry("600x400")
        # + Button
        self.add_button = ttk.Button(self.root, text="+ Add .exe App", command=self.select_exe_file)
        self.add_button.pack(pady=10)
        # Listbox to show installed apps
        self.app_listbox = tk.Listbox(self.root, width=60)
        self.app_listbox.pack(pady=10, fill=tk.BOTH, expand=True)
        # Load existing installed apps
        self.load_installed_apps()

    def select_exe_file(self):
        file_path = filedialog.askopenfilename(title="Select .exe file", filetypes=[("EXE files", "*.exe")])
        if file_path:
            try:
                # Copy .exe to INSTALL_DIR
                if not os.path.exists(INSTALL_DIR):
                    os.makedirs(INSTALL_DIR)

                file_name = os.path.basename(file_path)
                dest_path = os.path.join(INSTALL_DIR, file_name)
                shutil.copy2(file_path, dest_path)

                messagebox.showinfo("Success", f"App '{file_name}' installed successfully!")

            # Add to listbox
                self.app_listbox.insert(tk.END, file_name)

            # Resize window based on content
                self.auto_resize_window()

            except Exception as e:
                messagebox.showerror("Error", str(e))

    def load_installed_apps(self):
        if os.path.exists(INSTALL_DIR):
            apps = os.listdir(INSTALL_DIR)
            for app in apps:
                if app.endswith(".exe"):
                    self.app_listbox.insert(tk.END, app)

    def auto_resize_window(self):
        count = self.app_listbox.size()
        height = 150 + count * 20
        width = 600
        self.root.geometry(f"{width}x{height}")

    def main():
        root = tk.Tk()
        app = WindowsAppInstaller(root)
        root.mainloop()
        if name == "main":
            main()

def open2_login_screen():
    global login_window, password_entry, login_button, error_label, time_label,username_entry
    login_window = ctk.CTk()
    login_window.title("BLACKDEE Login")
    login_window.geometry(f"{login_window.winfo_screenwidth()}x{login_window.winfo_screenheight()}+0+0")
    login_window.attributes("-fullscreen", True)
    login_window.configure(bg="black")
    # ---------- Time and Date Update ----------
    def update_time():
        # Use after instead of an infinite loop
        current_time = datetime.now().strftime("%H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d")
        time_label.configure(text=f"{current_date} | {current_time}")
        login_window.after(1000, update_time)
    # ---------- Loading Animation (Arc and Animated Text) ----------
    def show_loading():
        # Hide login widgets
        password_entry.pack_forget()
        login_button.pack_forget()
        error_label.pack_forget()
        time_label.pack_forget()
        username_entry.pack_forget()
        # Create a canvas for the circle loading animation (using tk.Canvas)
        canvas = tk.Canvas(login_window, width=200, height=200, bg="black", highlightthickness=0)
        canvas.pack(pady=50)
        # Create an arc (circle outline) starting at 90° with extent 0
        arc = canvas.create_arc(10, 10, 190, 190, start=90, extent=0, outline="white", width=5, style="arc")

        # Label for animated text below the canvas
        animated_label = ctk.CTkLabel(login_window, text="", font=("Arial", 20), text_color="white", bg_color="black")
        animated_label.pack(pady=20)

        steps = 100          # 100 steps for the 5-second animation
        delay = 50           # 50 ms per step --> total = 5000 ms (5 seconds)

        def update_arc(step):
            if step <= steps:
                # Update the arc extent (0 to 360 degrees)
                extent = (step / steps) * 360
                canvas.itemconfig(arc, extent=extent)
                login_window.after(delay, update_arc, step + 1)
            else:
                # After finishing the animation, wait briefly then open the main menu
                login_window.after(500, lambda: (login_window.destroy()))

        def animate_text(index=0):
            message = "logging to the user..."
            if index <= len(message):
                animated_label.configure(text=message+(CORRECT_USERNAME)[:index])
                # Update text every 100 ms for a typing effect
                login_window.after(100, animate_text, index + 1)

        update_arc(0)
        animate_text(0)

    # ---------- Login Check Function ----------
    
    def check_login():
        username = username_entry.get()
        password = password_entry.get()
        if username == CORRECT_USERNAME and password == CORRECT_PASSWORD:
            show_loading()  # Proceed with login
        elif username != CORRECT_USERNAME and password != CORRECT_PASSWORD:
            error_label.configure(text="Incorrect Password", text_color="red")
        elif password != CORRECT_PASSWORD:
            error_label.configure(text="Incorrect Password", text_color="red")
        elif username != CORRECT_USERNAME:
            error_label.configure(text="Incorrect Password", text_color="red")



                
    def exit_app(event):
        login_window.destroy()
    login_window.bind("<Escape>", exit_app)

    
    # ---------- Create Widgets for Login ----------
    time_label = ctk.CTkLabel(login_window, text="", font=("Arial", 20), text_color="white", bg_color="black")
    time_label.pack(pady=20)
    update_time()  # Start the time/date updates
    username_entry = ctk.CTkEntry(login_window, placeholder_text="Enter Username", font=("Arial", 24), width=300)
    username_entry.pack(pady=20)
    password_entry = ctk.CTkEntry(login_window, placeholder_text="Enter Password", show="*", font=("Arial", 24), width=300)
    password_entry.pack(pady=20)
    login_button = ctk.CTkButton(login_window, text="Login", command=check_login)
    login_button.pack(pady=10)
    error_label = ctk.CTkLabel(login_window, text="", font=("Arial", 18), text_color="white", bg_color="black")
    error_label.pack()
    login_window.mainloop()


def open_file_txt():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open the Notepad app."""
    window = app_window("Notepad", "720x500")
    text_area = scrolledtext.ScrolledText(window, font=("Arial", 12))
    text_area.pack(expand=True)
    def save_file():
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(text_area.get("1.0", "end"))

    def open_file():
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
                text_area.delete("1.0", "end")
                text_area.insert("1.0", content)
    # Add buttons for saving and opening files
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Open", command=open_file).pack(side="left", padx=10)

    ctk.CTkButton(window, text="Save", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=save_file).pack(side="left", padx=10)
    
# Example App: Notepad
def open_notepad():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open the Notepad app."""
    window = app_window("Notepad", "720x500")
    text_area = scrolledtext.ScrolledText(window, wrap="word", font=("Arial", 12))
    text_area.pack(fill="both", expand=False)
    
    def save_file():
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(text_area.get("1.0", "end"))
    
    def open_file():
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
                text_area.delete("1.0", "end")
                text_area.insert("1.0", content)
    # Add buttons for saving and opening files
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Save", command=save_file).pack(side="left", padx=10)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Open", command=open_file).pack(side="left", padx=10)
    

def open_calculator():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a simple calculator."""
    if "Calculator" in running_apps:  # Prevent multiple instances
        running_apps["Calculator"].lift()
        return

    window = app_window("Calculator", "780x400")

    entry = ctk.CTkEntry(window, font=("Arial", 18), justify="right")
    entry.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=5, pady=5)

    def button_click(value):
        """Handles button clicks and updates the entry field."""
        entry.insert("end", value)

    def calculate():
        """Evaluates the mathematical expression in the entry field."""
        try:
            result = eval(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def clear():
        """Clears the entry field."""
        entry.delete(0, "end")

    def square():
        """Calculates the square of the number."""
        try:
            result = float(entry.get()) ** 2
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def square_root():
        """Calculates the square root."""
        try:
            result = math.sqrt(float(entry.get()))
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def reciprocal():
        """Calculates the reciprocal (1/x)."""
        try:
            result = 1 / float(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    # Layout buttons
    buttons = [
        ("7", "8", "9", "/"),
        ("4", "5", "6", "*"),
        ("1", "2", "3", "-"),
        ("0", ".", "=", "+"),
    ]

    for i, row in enumerate(buttons):
        for j, btn_text in enumerate(row):
            ctk.CTkButton(window, corner_radius=100,text=btn_text, command=lambda b=btn_text: button_click(b) if b != "=" else calculate()).grid(
                row=i + 1, column=j, sticky="nsew", padx=5, pady=5
            )

    # Special operation buttons
    ctk.CTkButton(window, text="C", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=clear).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="√", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=square_root).grid(row=5, column=2, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="x²", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=square).grid(row=5, column=3, sticky="nsew", padx=5, pady=5)
    ctk.CTkButton(window, text="1/x", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=reciprocal).grid(row=4, column=3, sticky="nsew", padx=5, pady=5)

    update_taskbar()  # Update the taskbar to show the running app
# Run the main loop


def shutdown_terminal():
    confirm = messagebox.askyesno("Shutdown", "Are you sure you want to shut down BLACKDEE?")
    if confirm:
        root.destroy()  # Closes the entire OS

def open_file_terminal():
    hide_menu()
    refresh_button.place_forget()

    def run_command():
        command = command_entry.get().strip()
        parts = command.split()
        
        if not command:
            return

        if command == "clear":
            terminal_output.delete("1.0", "end")

        elif command.startswith("linux dpt install "):
            app_name = command.replace("linux dpt install ", "").strip()
            if app_name and app_name not in installed_apps:
                installed_apps.append(app_name)
                update_dock()
                terminal_output.insert("end", f"Installed {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is already installed.\n")



        elif command == "Blackdee dpt list":
           terminal_output.insert("end", "Installed apps:\n" + "\n".join(installed_apps) + "\n" if installed_apps else "No apps installed.\n")

        elif command == "SHUTDOWN":
            shutdown_terminal()


        elif command == "credits":
            terminal_output.insert("end", "---------------------------------------------------------------------"+"\n"+"DEVEOPED BY:-DEEPDHANRAY"+"\n"+"UPDATED BY:-DEEPDHANRAY"+"\n"+"---------------------------------------------------------------------"+"\n")




        elif command.startswith("Blackdee dpt remove "):
            app_name = command.replace("linux dpt remove ", "").strip()
            if app_name in installed_apps:
                installed_apps.remove(app_name)
                update_dock()
                terminal_output.insert("end", f"Uninstalled {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is not installed.\n")

        elif command.startswith("echo "):
            terminal_output.insert("end", command.replace("echo ", "") + "\n")

        elif command == "exit":
            window.destroy()

        elif command == "date":
            terminal_output.insert("end", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n")

        elif command == "time":
            terminal_output.insert("end", datetime.datetime.now().strftime("%H:%M:%S") + "\n")

        elif command == "whoami":
            terminal_output.insert("end", os.getlogin() + "\n")

        elif command == "pwd":
            terminal_output.insert("end", os.getcwd() + "\n")

        elif command == "ls":
            terminal_output.insert("end", "\n".join(os.listdir()) + "\n")

        elif command.startswith("cd "):
            path = command.replace("cd ", "").strip()
            try:
                os.chdir(path)
                terminal_output.insert("end", f"Changed directory to {os.getcwd()}\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"Directory {path} not found.\n")

        elif command.startswith("mkdir "):
            dirname = command.replace("mkdir ", "").strip()
            os.makedirs(dirname, exist_ok=True)
            terminal_output.insert("end", f"Directory {dirname} created.\n")

        elif command.startswith("rmdir "):
            dirname = command.replace("rmdir ", "").strip()
            try:
                os.rmdir(dirname)
                terminal_output.insert("end", f"Directory {dirname} removed.\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"Directory {dirname} not found.\n")
            except OSError:
                terminal_output.insert("end", f"Directory {dirname} is not empty.\n")

        elif command.startswith("touch "):
            filename = command.replace("touch ", "").strip()
            open(filename, 'a').close()
            terminal_output.insert("end", f"File {filename} created.\n")

        elif command.startswith("rm "):
            filename = command.replace("rm ", "").strip()
            try:
                os.remove(filename)
                terminal_output.insert("end", f"File {filename} removed.\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"File {filename} not found.\n")

        elif command.startswith("cat "):
            filename = command.replace("cat ", "").strip()
            try:
                with open(filename, "r") as f:
                    terminal_output.insert("end", f.read() + "\n")
            except FileNotFoundError:
                terminal_output.insert("end", f"File {filename} not found.\n")

        elif command.startswith("cp "):
            try:
                _, src, dest = parts
                os.system(f"cp {src} {dest}")
                terminal_output.insert("end", f"Copied {src} to {dest}.\n")
            except:
                terminal_output.insert("end", "Usage: cp <source> <destination>\n")

        elif command.startswith("mv "):
            try:
                _, src, dest = parts
                os.system(f"mv {src} {dest}")
                terminal_output.insert("end", f"Moved {src} to {dest}.\n")
            except:
                terminal_output.insert("end", "Usage: mv <source> <destination>\n")

        elif command == "df":
            terminal_output.insert("end", subprocess.getoutput("df -h") + "\n")

        elif command == "du":
            terminal_output.insert("end", subprocess.getoutput("du -sh *") + "\n")

        elif command == "ps":
            terminal_output.insert("end", subprocess.getoutput("ps") + "\n")

        elif command.startswith("kill "):
            pid = command.replace("kill ", "").strip()
            os.system(f"kill {pid}")
            terminal_output.insert("end", f"Process {pid} terminated.\n")

        elif command == "uptime":
            terminal_output.insert("end", subprocess.getoutput("uptime") + "\n")

        elif command == "random":
            terminal_output.insert("end", f"{random.randint(1, 100)}\n")

        elif command == "login":
            terminal_output.insert("end", "USERNAME:-root" + "\n" + "PASSWORD:-blackdee"+"\n")
        elif command == "help":
            terminal_output.insert("end", "clear:- clear all the commands"+"\n"+"SHUTDOWN:-SHUTDOWN the Blackdee"+"\n"+"credits:-Show the name of the developer and updater"+"\n"+"exit:-Close the terminal"+"\n"+"date:-Display the Today date"+"\n"+"Time:-SHOW the real time"+"\n"+"whoami:-SHOW that you are ADMIN or not"+"\n"+"ls:-Show all the available version"+"\n"+"cd:-Change the directory of the ls command"+"\n"+"mkdir:-create new directory"+"\n"+"rmdir:- sHow that the directory is empty or not"+"\n"+"kill:-used to close any blackdee running proccess"+"\n"+"login:-Show the username and password"+"\n"+"random:-Can pick any random number"+"\n")
        else:
            terminal_output.insert("end", f"{command}" " is not recognized as an internal or external command,"+"\n"+ "operable program or batch file." +"\n")

        terminal_output.see("end")
        command_entry.delete(0, "end")

    window = app_window("Terminal", "720x500")
    terminal_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 12), bg="black", fg="green")
    terminal_output.pack(fill="both", expand=True)

    command_entry = ctk.CTkEntry(window, font=("Courier", 14))
    command_entry.pack(fill="x", padx=5, pady=5)
    ctk.CTkButton(window, text="Run",fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=run_command).pack()


# File Explorer
def open_file_explorer():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a file explorer."""
    window = app_window("File Explorer", "720x500")
    ctk.CTkButton(window, text="Browse Files", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png;*.txt")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    if filepath.endswith((".txt")):
            open_file_txt(filepath)
        

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img

def open_settings():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open the settings app."""
    window = app_window("Settings", "400x400")

    ttk.Label(window, text="BLACKDEE - Settings", font=("Arial", 14)).pack(pady=10)

    # Theme and Wallpaper
    ctk.CTkButton(window, text="Change Theme", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=change_theme).pack(pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Change Wallpaper", command=change_wallpaper).pack(pady=5)
    
    

    # Additional Settings
    ctk.CTkButton(window, text="Adjust Screen Brightness",  fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=adjust_brightness).pack(pady=5)
    ctk.CTkButton(window, text="Change Font Size", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=change_font_size).pack(pady=5)
    ctk.CTkButton(window, text="Enable/Disable Sound", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 ,command=toggle_sound).pack(pady=5)
    ctk.CTkButton(window, text="Set Default Apps",fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=set_default_apps).pack(pady=5)
    ctk.CTkButton(window, text="Manage Storage", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=manage_storage).pack(pady=5)
    ctk.CTkButton(window, text="Change Language", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=change_language).pack(pady=5)
    ctk.CTkButton(window, text="Update BLACKDEE", fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , command=update_blackdee).pack(pady=5)
    ctk.CTkButton(window, text="Check Battery Status", command=check_battery_status).pack(pady=5)
    ctk.CTkButton(window, text="Reset to Factory Settings", command=reset_factory).pack(pady=5)
    ctk.CTkButton(window, text="Privacy & Security", command=privacy_security).pack(pady=5)


def change_theme():
    messagebox.showinfo("Theme", "Theme changing coming soon.")
    
def change_wallpaper():
    file_path = filedialog.askopenfilename(title="Select Wallpaper", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")])
    if file_path:
        messagebox.showinfo("Wallpaper Changed", f"Wallpaper set to {file_path}")

def adjust_brightness():
    messagebox.showinfo("Brightness", "Brightness adjustment coming soon.")

def change_font_size():
    new_size = tk.simpledialog.askinteger("Font Size", "Enter new font size (e.g., 12, 14, 16):")
    if new_size:
        messagebox.showinfo("Font Size Changed", f"Font size set to {new_size}")

def toggle_sound():
    global sound_enabled
    sound_enabled = not sound_enabled
    state = "Enabled" if sound_enabled else "Disabled"
    messagebox.showinfo("Sound", f"Sound {state}")

def set_default_apps():
    apps = ["Browser", "Text Editor", "Music Player"]
    choice = tk.simpledialog.askstring("Default Apps", f"Enter default app ({', '.join(apps)}):")
    if choice in apps:
        messagebox.showinfo("Default App", f"Default {choice} set successfully.")

def manage_storage():
    total_space = "500GB"
    used_space = "200GB"
    free_space = "300GB"
    messagebox.showinfo("Storage Info", f"Total: {total_space}\nUsed: {used_space}\nFree: {free_space}")

def change_language():
    languages = ["English", "Spanish", "French"]
    choice = tk.simpledialog.askstring("Language", f"Choose language ({', '.join(languages)}):")
    if choice in languages:
        messagebox.showinfo("Language", f"Language set to {choice}")

def update_blackdee():
    webbrowser.open("https://blackdee-update.com")  # Replace with actual update URL
    messagebox.showinfo("Update", "Checking for updates...")

def check_battery_status():
    messagebox.showinfo("Coming soon!")

def reset_factory():
    confirm = messagebox.askyesno("Factory Reset", "Are you sure you want to reset BLACKDEE?")
    if confirm:
        messagebox.showinfo("Reset", "System resetting...")

def privacy_security():
    messagebox.showinfo("Privacy & Security", "Manage privacy settings in this section.")

# Global Variables
sound_enabled = True
        
#about
def open_file_about():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a new window to show the About app image."""
    about_window = tk.Toplevel(root)  # Create a new window
    about_window.title("About BLACKDEE")

    # Load the image safely
    try:
        img_path = r"D:\BLACKDEE WINDOWS\icons\app about.png"  # Update with your correct path
        img = Image.open(img_path)
        img = img.resize((1300, 600))  # Resize if needed
        img_tk = ImageTk.PhotoImage(img.copy())  # Ensure it's not garbage collected

        # Create a label to display the image
        img_label = tk.Label(about_window, image=img_tk)
        img_label.image = img_tk  # Keep reference
        img_label.pack(padx=10, pady=10)

    except Exception as e:
        error_label = tk.Label(about_window, text=f"Error loading image:\n{e}", fg="red")
        error_label.pack(pady=10)


# Load Shutdown Icon (Make sure "shutdown.png" is in the same directory)
about_img = ctk.CTkImage(light_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\about.png"), 
                            dark_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\about.png"), 
                            size=(25, 25))  # Resize image

os_label = ctk.CTkButton(helper_taskbar,image=about_img, text="BLACKDEE", compound="bottom",
                                fg_color="black", hover_color="blue", 
                                text_color="white", corner_radius=1000, 
                                command=open_file_about)
os_label.pack(side="right",pady=0.001,padx=50)

#image viewer
def open_file_imageviewer():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a file explorer."""
    window = app_window("Image viewer", "720x500")
    ctk.CTkButton(window, text="Image viewer", command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    else:
        messagebox.showinfo("File Selected", filepath)

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img
    
# adding tik tok toe


def tic_tac_toe():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    
    ttt_window = app_window("tik tok toe", "500x400")

    # Initialize game state
    board = [""] * 10
    current_player = "X"

    def check_winner():
        winning_combinations = [(0, 1, 2), (3, 4, 5), (6, 7, 8),
                                (0, 3, 6), (1, 4, 7), (2, 5, 8),
                                (0, 4, 8), (2, 4, 6)]
        for combo in winning_combinations:
            if board[combo[0]] == board[combo[1]] == board[combo[2]] and board[combo[0]] != "":
                return board[combo[0]]
        return None

    def make_move(index):
        nonlocal current_player
        if board[index] == "":
            board[index] = current_player
            buttons[index].config(text=current_player)

            winner = check_winner()
            if winner:
                result_label.config(text=f"Player {winner} wins!")
                for button in buttons:
                    button.config(state="disabled")
            elif "" not in board:
                result_label.config(text="It's a tie!")
            else:
                current_player = "O" if current_player == "X" else "X"

    # Create buttons for the Tic-Tac-Toe grid
    buttons = []
    for i in range(9):
        button = tk.Button(ttt_window, text="", font=("Arial", 8), width=5, height=2,
                           command=lambda index=i: make_move(index))
        button.grid(row=i // 3, column=i % 3)
        buttons.append(button)

    result_label = tk.Label(ttt_window, text="", font=("Arial", 14))
    result_label.grid(row=3, columnspan=3)

#adding music player
def music_player():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    window = app_window("Music Player", "400x200")
    
    def play_music():
        file_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3;*.wav")])
        if file_path:
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()

    def stop_music():
        pygame.mixer.music.stop()

    ctk.CTkButton(window, text="Play Music", command=play_music).pack(pady=20)
    ctk.CTkButton(window, text="Stop Music", command=stop_music).pack(pady=20)

# creating web brower



# Initialize the main window
def CustomWebBrowser():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    add_google_logo()
    add_search_bar()

    root.mainloop()

# Function to display Google logo
def add_google_logo():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    google_logo = HTMLLabel(root, html="""
        <div style="text-align:center;">
            <img src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_light_color_92x30dp.png">
        </div>
    """)
    google_logo.pack(pady=10)

# Function to create the search bar
def add_search_bar():
    global search_entry
    search_frame = ctk.CTkFrame(window)
    search_frame.pack(pady=10)

    search_entry = ctk.CTkEntry(search_frame, width=400, placeholder_text="Search Google...")
    search_entry.pack(side=tk.LEFT, padx=5)

    search_button = ctk.CTkButton(search_frame, text="Search", command=search_google)
    search_button.pack(side=tk.LEFT)

# Function to open Google search results in the app
def search_google():
    query = search_entry.get()
    if query:
        url = f"https://www.google.com/search?q={query}"
        webview.create_window("Search Results", url)
        webview.start()

#adding paint

def paint_app():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    window = app_window("Paint", "600x400")
    
    # Create a canvas for drawing
    canvas = tk.Canvas(window, bg="white", width=600, height=400)
    canvas.pack(fill="both", expand=True)
    
    # Initialize variables
    current_tool = "pen"
    pen_color = "black"
    
    def paint(event):
        """Draws on the canvas based on the selected tool."""
        x1, y1 = (event.x - 2), (event.y - 2)
        x2, y2 = (event.x + 2), (event.y + 2)
        if current_tool == "pen":
            canvas.create_oval(x1, y1, x2, y2, fill=pen_color, outline=pen_color)
        elif current_tool == "eraser":
            canvas.create_rectangle(x1, y1, x2, y2, fill="white", outline="white")
    
    def set_tool(tool):
        """Sets the current drawing tool."""
        nonlocal current_tool
        current_tool = tool
    
    def set_color(new_color):
        """Changes the pen color."""
        nonlocal pen_color
        pen_color = new_color
    
    def draw_line():
        """Activates line drawing mode."""
        set_tool("line")
        canvas.bind("<Button-1>", start_line)
        canvas.bind("<ButtonRelease-1>", end_line)
    
    def start_line(event):
        """Stores start position for line drawing."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_line(event):
        """Draws a line from start to end position."""
        canvas.create_line(canvas.start_x, canvas.start_y, event.x, event.y, fill=pen_color, width=2)
    
    def draw_rectangle():
        """Activates rectangle drawing mode."""
        set_tool("rectangle")
        canvas.bind("<Button-1>", start_rectangle)
        canvas.bind("<ButtonRelease-1>", end_rectangle)
    
    def start_rectangle(event):
        """Stores start position for rectangle."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_rectangle(event):
        """Draws a rectangle from start to end position."""
        canvas.create_rectangle(canvas.start_x, canvas.start_y, event.x, event.y, outline=pen_color, width=2)
    
    def draw_circle():
        """Activates circle drawing mode."""
        set_tool("circle")
        canvas.bind("<Button-1>", start_circle)
        canvas.bind("<ButtonRelease-1>", end_circle)
    
    def start_circle(event):
        """Stores start position for circle."""
        canvas.start_x = event.x
        canvas.start_y = event.y
    
    def end_circle(event):
        """Draws a circle from start to end position."""
        x1, y1 = canvas.start_x, canvas.start_y
        x2, y2 = event.x, event.y
        canvas.create_oval(x1, y1, x2, y2, outline=pen_color, width=2)
    
    def clear_canvas():
        """Clears the canvas."""
        canvas.delete("all")
    
    def save_canvas():
        """Saves the canvas as an image."""
        file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                 filetypes=[("PNG files", "*.png"), ("All Files", "*.*")])
        if file_path:
            canvas.postscript(file="temp_canvas.ps", colormode="color")
            img = Image.open("temp_canvas.ps")
            img.save(file_path)
            messagebox.showinfo("Saved", "Image saved successfully!")

    # Color palette with 20 colors
    colors = ["black", "gray", "red", "blue", "green", "yellow", "orange", "purple", "pink", "brown",
              "cyan", "magenta", "lime", "navy", "gold", "maroon", "teal", "violet", "indigo", "darkgreen"]
    
    color_frame = tk.Frame(window)
    color_frame.pack()
    
    for color in colors:
        btn = tk.Button(color_frame, bg=color, width=1, command=lambda c=color: set_color(c))
        btn.pack(side="left", padx=0.008, pady=0.008)
    
    # Tools
    
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Pen", command=lambda: set_tool("pen")).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Eraser", command=lambda: set_tool("eraser")).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Line", command=draw_line).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Rectangle", command=draw_rectangle).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Circle", command=draw_circle).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Clear", command=clear_canvas).pack(side="left", padx=5, pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Save", command=save_canvas).pack(side="left", padx=5, pady=5)
    
    canvas.bind("<B1-Motion>", paint)  # Allows continuous drawing

#adding clock     
def clock_app():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    window = app_window("Clock", "400x200")
    def update_clock():
        """Update the clock every second (both digital and analog)."""
        current_time = time.strftime("%I:%M:%S")  # Get current time
        clock_label.config(text=current_time)  # Update digital clock text
        # Clear previous clock drawing
        clock_canvas.delete("all")
        # Draw clock face
        clock_canvas.create_oval(10, 10, 110, 110, outline="black", width=3, fill="yellow")
        # Draw numbers
        for i in range(1, 13):
            angle = math.radians(i * 30 - 90)
            x = 60 + 40 * math.cos(angle)
            y = 60 + 40 * math.sin(angle)
            clock_canvas.create_text(x, y, text=str(i), font=("Arial", 10, "bold"), fill="black")
        # Get current time values
        hours = int(time.strftime("%I"))
        minutes = int(time.strftime("%M"))
        seconds = int(time.strftime("%S"))
        # Calculate angles
        second_angle = math.radians((seconds * 6) - 90)
        minute_angle = math.radians((minutes * 6) - 90)
        hour_angle = math.radians((hours * 30 + minutes * 0.5) - 90)
        # Draw hands
        def draw_hand(angle, length, color, width=2):
            x = 60 + length * math.cos(angle)
            y = 60 + length * math.sin(angle)
            clock_canvas.create_line(60, 60, x, y, fill=color, width=width)
        draw_hand(hour_angle, 25, "black", 4)
        draw_hand(minute_angle, 35, "blue", 3)
        draw_hand(second_angle, 40, "red", 1)
        # Schedule next update
        clock_label.after(1000, update_clock)
        #creating a animation time# Create taskbar clock UI elements
    clock_label = tk.Label(window, text="", fg="blue", font=("Arial", 1, "bold"))
    clock_canvas = Canvas(window,width=120, height=120, bg="#2e3440")
    clock_canvas.pack(side="left", padx=5, pady=5)
    update_clock()
    clock_label = tk.Label(window, text="", bg=theme_colors[current_theme]["taskbar"], fg="blue", font=("Arial", 30))
    clock_label.pack(side="left", padx=0.02, pady=0.01)
# Start updating the clock
    update_clock()
                          
# todo list
def todo_list():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    window = app_window("To-Do List", "400x400")
    
    tasks = []

    def add_task():
        task = entry.get()
        if task:
            tasks.append(task)
            listbox.insert("end", task)
            entry.delete(0, "end")

    def remove_task():
        selected_task = listbox.curselection()
        if selected_task:
            task_index = selected_task[0]
            listbox.delete(task_index)
            tasks.pop(task_index)

    entry = ctk.CTkEntry(window, width=40)
    entry.pack(pady=10)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Add Task", command=add_task).pack(pady=5)
    ctk.CTkButton(window, fg_color="black", hover_color="blue", text_color="white", corner_radius=10 , text="Remove Task", command=remove_task).pack(pady=5)

    listbox = tk.Listbox(window, height=10, width=50)
    listbox.pack(pady=10)                                                                                          

def open_video_player():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    """Open a video player with proper video-audio synchronization."""
    
    # Hide the root Tkinter window
    root = tk.Tk()
    root.withdraw()
    
    # Ask user to select a video file
    file_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi;*.mov;*.mkv")])
    
    if not file_path:
        print("No file selected.")
        return
    
    # Initialize pygame
    pygame.init()
    
    # Load video using OpenCV
    cap = cv2.VideoCapture(file_path)
    
    if not cap.isOpened():
        print("Error: Could not open video file.")
        return
    
    # Get video properties
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_time = 10/ fps  # Time per frame in milliseconds

    # Create a Pygame window
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Video Player")

    # Extract and convert audio
    audio_path = "temp_audio.wav"
    try:
        ffmpeg.input(file_path).output(audio_path, format='wav', acodec='pcm_s16le', loglevel="quiet").run(overwrite_output=True)
    except Exception as e:
        print(f"Error extracting audio: {e}")
        return

    # Initialize pygame.mixer AFTER extracting audio
    pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)

    # Load and play audio
    try:
        pygame.mixer.music.load(audio_path)
        pygame.mixer.music.play()
        audio_start_time = pygame.time.get_ticks()  # Get the time when audio starts
    except Exception as e:
        print(f"Error playing audio: {e}")
        return

    running = True
    clock = pygame.time.Clock()

    while running:
        ret, frame = cap.read()
        
        if not ret:
            break  # Stop if the video ends
        
        # Convert frame to RGB for pygame
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = pygame.surfarray.make_surface(frame.swapaxes(0, 1))

        # Display frame
        screen.blit(frame, (0, 0))
        pygame.display.update()

        # Synchronize video with audio
        while pygame.time.get_ticks() - audio_start_time < cap.get(cv2.CAP_PROP_POS_MSEC):
            time.sleep(0.001)  # Small sleep to keep the timing accurate

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
        clock.tick(fps)

    # Cleanup
    cap.release()
    pygame.quit()
    pygame.mixer.quit()
    
    # Remove temporary audio file
    if os.path.exists(audio_path):
        os.remove(audio_path)


def shutdown():
    hide_menu()
    refresh_button.place_forget()  # Hide refresh button

    confirm = messagebox.askyesno("Shutdown", "Are you sure you want to shut down BLACKDEE?")
    if confirm:
        shutdown_screen = tk.Toplevel(root)
        shutdown_screen.attributes('-fullscreen', True)  # Make it full screen
        shutdown_screen.configure(bg="black")  # Set background to black

        # === Video Player at the Bottom ===
        video_label = tk.Label(shutdown_screen, bg="black")  
        video_label.place(relx=0.5, rely=0.5, anchor="center")

        # Load video file (Change to your video path)
        video_path = "D:\\BLACKDEE WINDOWS\\icons\\InShot_20250302_121751912.mp4"  # Replace with actual video path
        cap = cv2.VideoCapture(video_path)
     
        # Timer Label (inside the circle)
        countdown_label = tk.Label(shutdown_screen, text="10", font=("Arial", 30, "bold"), fg="white", bg="black")
        

        

        # Rotating Circle Animation
        canvas = tk.Canvas(shutdown_screen, width=100, height=100, bg="black", highlightthickness=0)
        canvas.pack()
        arc = canvas.create_arc(10, 10, 90, 90, start=0, extent=270, outline="blue", width=10, style="arc")
         
        # === Function to Update Video Frame ===#
        def play_video():
            
            ret, frame = cap.read()
            if ret:
                frame = cv2.resize(frame, (1366,768 ))  # Resize video
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = Image.fromarray(frame)
                frame = ImageTk.PhotoImage(frame)
                video_label.config(image=frame)
                video_label.image = frame
                root.after(10, play_video)  # Adjust frame rate
        play_video()




        
        def animate_circle(angle=0):
            canvas.itemconfig(arc, start=angle)
            new_angle = (angle + 10) % 360  # Rotate animation
            if int(countdown_label["text"]) > 0:
                shutdown_screen.after(50, animate_circle, new_angle)  # Update every 50ms

        animate_circle()  # Start animation

        def countdown(seconds):
            if seconds > 0:
                countdown_label.config(text=str(seconds))
                shutdown_screen.after(1000, countdown, seconds - 1)  # Update every second
            else:
                root.destroy()  # Shutdown BLACKDEE

        countdown(10)  # Start countdown

# Load Shutdown Icon (Make sure "shutdown.png" is in the same directory)
shutdown_img = ctk.CTkImage(light_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\shutdown_button.png"), 
                            dark_image=Image.open(r"D:\BLACKDEE WINDOWS\icons\shutdown_button.png"), 
                            size=(50, 25))  # Resize image



# Create Shutdown Button
shutdown_button = ctk.CTkButton(helper_taskbar, text="Shutdown", image=shutdown_img, compound="right",
                                fg_color="black", hover_color="blue", 
                                text_color="red", corner_radius=100, 
                                command=shutdown)
shutdown_button.pack(pady=0.000005)

# Correct Password
CORRECT_PASSWORD = "blackdee"
CORRECT_USERNAME = "root"

def distroytask():
    right.destroy()
    

def right():
    # Right Taskbar (Only Open Apps)
    _taskbar = tk.Frame(root)
    _taskbar.pack(side="left", fill="y",padx=0.0001,pady=0.10)
    ai_button = tk.Button(_taskbar, text="AI(NOT COMPLETE)", compound="top")
    ai_button.pack(pady=0.000005,side="top")

    
    def off_task():
        _taskbar.destroy()
        ff_button.destroy()
    # Create close taskbar Button
    ff_button = tk.Button(taskbar, text="clear taskbar", compound="left",command=off_task)
    ff_button.pack(pady=0.000005,side="left")
    

on_button = tk.Button(helper_taskbar, text=">", compound="right",command=right)
on_button.pack(pady=0.000005)
# Create open taskbar Button

def distroytask():
    right.destroy()
    helper_taskbar.destroy()
    taskbar.destroy()
    right_taskbar.destroy()
    
theme_colors = {
    "default": {"theme": "#2e3440", "taskbar": "#3b4252", "text": "#eceff4", "button": "#5e81ac", "hover": "#81a1c1"},
    "light": {"theme": "#ffffff", "taskbar": "#dcdcdc", "text": "#000000", "button": "#d3d3d3", "hover": "#c0c0c0"}
}
current_theme = "default"


def theme():
    # Right Taskbar (Only Open Apps)
    classic_taskbar = tk.Frame(root, bg="#3b4252", height=50,padx=0.10)
    classic_taskbar.pack(side="bottom", fill="x")
    classic_right_taskbar = tk.Frame(root, bg=theme_colors[current_theme]["taskbar"], width=150)
    classic_right_taskbar.pack(side="right", fill="y")
    helper_taskbar.destroy()
    taskbar.destroy()
    right_taskbar.destroy()
    clock_canvas.destroy()
    theme_start_menu_var = tk.StringVar
    theme_start_menu_var("Start")
    theme_start_menu = ttk.OptionMenu(classic_taskbar, theme_start_menu_var, *["Start"] + installed_apps, command=lambda app: open_app(app))
    theme_start_menu.pack(side="bottom", padx=0)
    # Create close taskbar Button

theme_button = tk.Button(helper_taskbar, text="change theme", compound="right",command=theme)
theme_button.pack(pady=0.000005)

root.mainloop()

