import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import math

# Theme colors
theme_colors = {
    "default": {"theme": "#2e3440", "taskbar": "#3b4252", "text": "#eceff4", "button": "#5e81ac", "hover": "#81a1c1"},
    "light": {"theme": "#ffffff", "taskbar": "#dcdcdc", "text": "#000000", "button": "#d3d3d3", "hover": "#c0c0c0"}
}
current_theme = "default"

# Initialize main window
root = tk.Tk()
root.title("BLACKDEE")
root.geometry("720x1544")
root.configure(bg=theme_colors[current_theme]["theme"])

# Taskbar
taskbar = tk.Frame(root, bg=theme_colors[current_theme]["taskbar"], height=50)
taskbar.pack(side="bottom", fill="x")

running_apps_display = tk.Frame(taskbar, bg=theme_colors[current_theme]["taskbar"])
running_apps_display.pack(side="right", padx=10)

start_menu_var = tk.StringVar()
start_menu_var.set("Start")

installed_apps = [
    "File Explorer", "Settings", "Calculator", "Notepad", "Image Viewer","about","terminal"
]
start_menu = ttk.OptionMenu(
    taskbar, start_menu_var, *["Start"] + installed_apps, command=lambda app: open_app(app)
)
start_menu.pack(side="left", padx=0)

os_label = ttk.Label( text="BLACKDEE ", background=theme_colors[current_theme]["taskbar"], foreground="gray")
os_label.pack(padx=120, pady = 50)

# Helper functions
running_apps = {}

def update_taskbar():
    """Update the taskbar with running apps."""
    for widget in running_apps_display.winfo_children():
        widget.destroy()


    for app_name in running_apps.keys():
        ttk.Button(
            running_apps_display,
            text=app_name,
            command=lambda a=app_name: running_apps[a].lift()
        ).pack(side="left", padx=10)

def app_window(app_name, size):
    """Create a new window for an app."""
    window = tk.Toplevel(root)
    window.title(app_name)
    window.geometry(size)
    window.configure(bg=theme_colors[current_theme]["theme"])
    running_apps[app_name] = window

    def close_app():
        del running_apps[app_name]
        window.destroy()
        update_taskbar()

    window.protocol("WM_DELETE_WINDOW", close_app)
    update_taskbar()
    return window
    
    
    # 1. Terminal App
def open_file_terminal():
    def run_command():
        command = command_entry.get()
        if command.startswith("linux dpt install "):
            app_name = command.replace("linux dpt install ", "").strip()
            if app_name and app_name not in installed_apps:
                installed_apps.append(app_name)
                update_dock()
                terminal_output.insert("end", f"Installed {app_name} successfully.\n")
            else:
                terminal_output.insert("end", f"{app_name} is already installed.\n")
        else:
            try:
                output = subprocess.getoutput(command)
                terminal_output.insert("end", f"> {command}\n{output}\n")
            except Exception as e:
                terminal_output.insert("end", f"Error: {str(e)}\n")
        terminal_output.see("end")
        command_entry.delete(0, "end")

    window = app_window("Terminal", "720x500")
    terminal_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 12), bg="black", fg="green")
    terminal_output.pack(fill="both", expand=True)
    command_entry = ttk.Entry(window, font=("Courier", 14))
    command_entry.pack(fill="x", padx=5, pady=5)
    ttk.Button(window, text="Run", command=run_command).pack()

def open_termux():
    window = app_window("Termux", "400x400")
    termux_output = scrolledtext.ScrolledText(window, wrap="word", font=("Courier", 0.50), bg="black", fg="green")
    termux_output.pack(fill="both", expand=True)
    termux_output.insert("end", "Termux Shell: Welcome!\n")
    termux_output.insert("end", "Use commands like 'ls' or 'pwd'.")

# Open apps
def open_app(app_name):
    if app_name in running_apps:
        running_apps[app_name].lift()
        return
    if app_name == "terminal":
        open_file_terminal() 
    if app_name == "File Explorer":
        open_file_explorer()
    elif app_name == "Settings":
        open_settings()
    elif app_name == "Calculator":
        open_calculator()
    elif app_name == "Notepad":
        open_notepad()
    elif app_name == "Image Viewer":
        open_file_imageviewer()
    elif app_name == "about":
        open_file_about() 
       
# File Explorer
def open_file_explorer():
    """Open a file explorer."""
    window = app_window("File Explorer", "720x500")
    ttk.Button(window, text="Browse Files", command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    else:
        messagebox.showinfo("File Selected", filepath)

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img



# Calculator
def open_calculator():
    """Open a simple calculator."""
    import math

# Function to open the calculator window
def open_calculator():
    """Open a simple calculator."""
   
    window = tk.Toplevel(root)
    window.title("Calculator")
    window.geometry("800x400")
    window.configure(bg="#f0f0f0")
    window = app_window("Calculator", "720x500")
    

    entry = ttk.Entry(window, font=("Arial", 18), justify="right")
    entry.grid(row=0, column=0, columnspan=4, sticky="nsew")

    def button_click(value):
        current_text = entry.get()
        entry.delete(0, "end")
        entry.insert("end", current_text + value)

    def calculate():
        try:
            result = eval(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def clear():
        entry.delete(0, "end")

    def square():
        try:
            result = float(entry.get()) ** 2
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def square_root():
        try:
            result = math.sqrt(float(entry.get))
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    def reciprocal():
        try:
            result = 1 / float(entry.get())
            entry.delete(0, "end")
            entry.insert("end", str(result))
        except:
            entry.delete(0, "end")
            entry.insert("end", "Error")

    buttons = [
        ("7", "8", "9", "/"),
        ("4", "5", "6", "*"),
        ("1", "2", "3", "-"),
        ("0", ".", "=", "+"),
    ]

    for i, button_row in enumerate(buttons):
        for j, button in enumerate(button_row):
            ttk.Button(window, text=button, command=lambda b=button: button_click(b) if b != "=" else calculate()).grid(
                row=i + 1, column=j, sticky="nsew", padx=5, pady=5
            )

    # Add extra operation buttons
    ttk.Button(window, text="C", command=clear).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="√", command=square_root).grid(row=5, column=2, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="x²", command=square).grid(row=5, column=3, sticky="nsew", padx=5, pady=5)
    ttk.Button(window, text="1/x", command=reciprocal).grid(row=4, column=3, sticky="nsew", padx=5, pady=5)(fill="both", expand=True)
    
    def button_click(value):
        current_text = entry.get()
        entry.delete(0, "end")
        entry.insert("end", current_text + value)
  
# Notepad
def open_notepad():
    """Open the Notepad app."""
    window = app_window("Notepad", "720x500")
    text_area = scrolledtext.ScrolledText(window, wrap="word", font=("Arial", 12))
    text_area.pack(fill="both", expand=True)
    
    def save_file():
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "w") as file:
                file.write(text_area.get("1.0", "end"))
    
    def open_file():
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
                text_area.delete("1.0", "end")
                text_area.insert("1.0", content)

    # Add buttons for saving and opening files
    ttk.Button(window, text="Save", command=save_file).pack(side="left", padx=10)
    ttk.Button(window, text="Open", command=open_file).pack(side="left", padx=10)

# Settings
def open_settings():
    """Open the settings app."""
    window = app_window("Settings", "720x500")
    ttk.Label(window, text="BLACKDEE", font=("Arial", 14)).pack(pady=10)

    # Add options for theme and wallpaper
    ttk.Button(window, text="Change Theme", command=change_theme).pack(pady=5)
    ttk.Button(window, text="Change Wallpaper", command=change_wallpaper).pack(pady=5)

def change_theme():
    """Switch between light and default themes."""
    global current_theme
    current_theme = "light" if current_theme == "default" else "default"
    root.configure(bg=theme_colors[current_theme]["theme"])
    taskbar.configure(bg=theme_colors[current_theme]["taskbar"])
    os_label.configure(background=theme_colors[current_theme]["taskbar"])
    messagebox.showinfo("Theme Changed", f"Switched to {current_theme} theme.")

def change_wallpaper():
    """Change the desktop wallpaper."""
    filepath = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg;*.png")])
    if filepath:
        img = Image.open(filepath)
        img = img.resize((800, 600))
        img = ImageTk.PhotoImage(img)
        root.configure(bg=theme_colors[current_theme]["theme"])
        root.image = img # Keep a reference to avoid garbage collection

#about
def open_file_about():
     window = app_window("about","720x200")
     messagebox.showinfo("File Selected")
#image viewer
def open_file_imageviewer():
    """Open a file explorer."""
    window = app_window("Image viewer", "720x500")
    ttk.Button(window, text="Image viewer", command=lambda: browse_files(window)).pack(pady=20)

def browse_files(window):
    """Browse files and open images."""
    filepath = filedialog.askopenfilename(filetypes=[("All Files", "*.*"), ("Image Files", "*.jpg;*.png")])
    if filepath.endswith((".jpg", ".png")):
        open_image(filepath)
    else:
        messagebox.showinfo("File Selected", filepath)

def open_image(filepath):
    """Open and display an image."""
    img = Image.open(filepath)
    img = img.resize((800, 600))
    img = ImageTk.PhotoImage(img)
    window = app_window("Image Viewer", "500x500")
    tk.Label(window, image=img).pack()
    window.image = img
      
        
# Run the main loop
root.mainloop()
